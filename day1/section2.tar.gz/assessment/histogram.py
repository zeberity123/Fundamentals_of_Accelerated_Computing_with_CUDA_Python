# Add your solution here
from numba import cuda
from numba import jit
import numpy as np

@cuda.jit
def cuda_histogram(x, xmin, xmax, histogram_out):
    '''Increment bin counts in histogram_out, given histogram range [xmin, xmax).'''
    
#     pass  # Replace this with your implementation
    nbins = histogram_out.shape[0]
    idx = cuda.grid(1)
    bin_width = (xmax - xmin) / nbins
    stride = cuda.gridsize(1)
    for i in range(idx, x.shape[0], stride):
        bin_number = np.int32((x[i] - xmin)/bin_width)
        if bin_number >= 0 and bin_number < nbins:
            cuda.atomic.add(histogram_out, bin_number, 1)